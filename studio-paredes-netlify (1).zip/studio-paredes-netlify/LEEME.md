# Studio Paredes · Portafolio (Netlify)

## Subir a Netlify
1. Sube esta carpeta a un repositorio de GitHub.
2. En Netlify: Add new site > Import an existing project > elige el repositorio. No cambies nada, ya está configurado.
3. Antes de publicar: Site configuration > Environment variables > crea `ADMIN_PASSWORD` con la contraseña de Isabel.
4. Deploy. Para cambiar la contraseña después, edita esa variable y vuelve a desplegar.
5. Dominio propio: Domain management > Add a domain.

## Uso de Isabel
Entra a "Acceso privado" (al final de la página), pon la contraseña, edita y pulsa "Publicar cambios".
Las fotos y textos se guardan en Netlify Blobs.
